//GigiCruz
//CS 320
//March 2026
//Version 2

package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Contact.Contact;

class ContactTest {

    //  Constructor tests 
    @Test
    @DisplayName("Valid constructor")
    void testGoodConstructor() {
        Contact testContact = new Contact("1", "Jane", "Doe", "1023456789", "123 Home Street");
        assertEquals("1", testContact.getContactId());
        assertEquals("Jane", testContact.getFirstName());
        assertEquals("Doe", testContact.getLastName());
        assertEquals("1023456789", testContact.getNumber());
        assertEquals("123 Home Street", testContact.getAddress());
    }

    @Test
    @DisplayName("Constructor with invalid phone")
    void testBadConstructorPhone() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("2", "Jane", "Doe", "123", "123 Home Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("2", "Jane", "Doe", "12345abcde", "123 Home Street"));
    }

    @Test
    @DisplayName("Constructor with too long ID")
    void testBadConstructorId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Jane", "Doe", "1023456789", "123 Home Street"));
    }

    @Test
    @DisplayName("Constructor with null values")
    void testConstructorNulls() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Jane", "Doe", "1023456789", "123 Home Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("3", null, "Doe", "1023456789", "123 Home Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("3", "Jane", null, "1023456789", "123 Home Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("3", "Jane", "Doe", "1023456789", null));
    }

    // First name tests 
    @Test
    @DisplayName("Valid setFirstName")
    void testGoodSetFirst() {
        Contact testContact = new Contact("4", "Jane", "Doe", "1023456789", "123 Home Street");
        testContact.setFirstName("Test");
        assertEquals("Test", testContact.getFirstName());
    }

    @Test
    @DisplayName("Invalid setFirstName")
    void testLongSetFirst() {
        Contact testContact = new Contact("4", "Jane", "Doe", "1023456789", "123 Home Street");
        assertThrows(IllegalArgumentException.class, () -> testContact.setFirstName("ThisNameIsTooLong"));
        assertThrows(IllegalArgumentException.class, () -> testContact.setFirstName(null));
    }

    //  Last name tests 
    @Test
    @DisplayName("Valid setLastName")
    void testGoodSetLast() {
        Contact testContact = new Contact("5", "Jane", "Doe", "1023456789", "123 Home Street");
        testContact.setLastName("Test");
        assertEquals("Test", testContact.getLastName());
    }

    @Test
    @DisplayName("Invalid setLastName")
    void testLongSetLast() {
        Contact testContact = new Contact("5", "Jane", "Doe", "1023456789", "123 Home Street");
        assertThrows(IllegalArgumentException.class, () -> testContact.setLastName("ThisLastNameIsTooLong"));
        assertThrows(IllegalArgumentException.class, () -> testContact.setLastName(null));
    }

    //  Phone tests 
    @Test
    @DisplayName("Valid phone")
    void testGoodPhone() {
        Contact testContact = new Contact("6", "Jane", "Doe", "1023456789", "123 Home Street");
        testContact.setPhone("1234561234");
        assertEquals("1234561234", testContact.getNumber());
    }

    @Test
    @DisplayName("Invalid phone")
    void testInvalidPhone() {
        Contact testContact = new Contact("6", "Jane", "Doe", "1023456789", "123 Home Street");
        assertThrows(IllegalArgumentException.class, () -> testContact.setPhone("123"));
        assertThrows(IllegalArgumentException.class, () -> testContact.setPhone("12345abcde"));
        assertThrows(IllegalArgumentException.class, () -> testContact.setPhone(null));
    }

    //  Address tests 
    @Test
    @DisplayName("Valid address")
    void testGoodAddress() {
        Contact testContact = new Contact("7", "Jane", "Doe", "1023456789", "123 Home Street");
        testContact.setAddress("456 New Street");
        assertEquals("456 New Street", testContact.getAddress());
    }

    @Test
    @DisplayName("Invalid address")
    void testInvalidAddress() {
        Contact testContact = new Contact("7", "Jane", "Doe", "1023456789", "123 Home Street");
        assertThrows(IllegalArgumentException.class, () -> testContact.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> testContact.setAddress("ThisAddressIsWayTooLongToBeValidBecauseItExceeds30Characters"));
    }
}