//GigiCruz
//CS 320
//March 2026
//Version 2

package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Contact.ContactService;
import Contact.Contact;

class ContactServiceTest {

    private ContactService service;

    @AfterEach
    void tearDown() {
        service = null; // reset
    }

    //  Add contact tests 
    @Test
    @DisplayName("Add a single contact")
    void testAddContact() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");

        assertEquals(1, service.getContactList().size());
        Contact c = service.getContactList().get(0);
        assertEquals("0", c.getContactId());
        assertEquals("Jane", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getNumber());
        assertEquals("123 Home Street", c.getAddress());
    }

    @Test
    @DisplayName("Add multiple contacts")
    void testAddMultipleContacts() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");
        service.addContact("John", "Smith", "0987654321", "456 Main Street");

        assertEquals(2, service.getContactList().size());
        assertEquals("0", service.getContactList().get(0).getContactId());
        assertEquals("1", service.getContactList().get(1).getContactId());
    }

    //  Delete tests 
    @Test
    @DisplayName("Delete existing contact")
    void testDeleteContact() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");
        service.addContact("John", "Smith", "0987654321", "456 Main Street");

        service.deleteContact("0");
        assertEquals(1, service.getContactList().size());
        assertEquals("1", service.getContactList().get(0).getContactId());
    }

    @Test
    @DisplayName("Delete non-existent contact")
    void testDeleteNonExistent() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");

        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("5"));
    }

    //  Update first name 
    @Test
    @DisplayName("Edit first name")
    void testEditFirstName() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");
        service.editFirstName("0", "Janet");

        assertEquals("Janet", service.getContactList().get(0).getFirstName());
    }

    @Test
    @DisplayName("Edit first name invalid ID")
    void testEditFirstNameInvalid() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");

        assertThrows(IllegalArgumentException.class, () -> service.editFirstName("5", "Janet"));
    }

    //  Update last name 
    @Test
    @DisplayName("Edit last name")
    void testEditLastName() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");
        service.editLastName("0", "Smith");

        assertEquals("Smith", service.getContactList().get(0).getLastName());
    }

    //  Update phone 
    @Test
    @DisplayName("Edit phone")
    void testEditPhone() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");
        service.editPhoneNumber("0", "0987654321");

        assertEquals("0987654321", service.getContactList().get(0).getNumber());
    }

    @Test
    @DisplayName("Edit phone invalid ID")
    void testEditPhoneInvalid() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");

        assertThrows(IllegalArgumentException.class, () -> service.editPhoneNumber("5", "0987654321"));
    }

    //  Update address 
    @Test
    @DisplayName("Edit address")
    void testEditAddress() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");
        service.editAddress("0", "456 New Street");

        assertEquals("456 New Street", service.getContactList().get(0).getAddress());
    }

    @Test
    @DisplayName("Edit address invalid ID")
    void testEditAddressInvalid() {
        service = new ContactService();
        service.addContact("Jane", "Doe", "1234567890", "123 Home Street");

        assertThrows(IllegalArgumentException.class, () -> service.editAddress("5", "456 New Street"));
    }
}